package com.source.rabbitmq.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRabbitmqExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
