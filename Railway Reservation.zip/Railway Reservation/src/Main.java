import java.util.Scanner;

public class Main {


    public static void bookTickets(Passenger p) {
        Booking bookTickets = new Booking();

        if(Booking.availableWaitingList == 0){
            System.out.println("No Tickets Available..!");
            return;
        }

        if((p.getBerthPrefer().equals("L") && Booking.availableLowerBerths>0) ||
                (p.getBerthPrefer().equals("M") && Booking.availableMiddleBerths>0) ||
                (p.getBerthPrefer().equals("U") && Booking.availableUpperBerths>0))
        {
            System.out.println("Preferred Berth Available");

            if(p.getBerthPrefer().equals("L")){
                System.out.println("Lower Berth given ");
                bookTickets.bookTickets(p, (Booking.lowerBerthPositions.get(0)),"L");
                Booking.lowerBerthPositions.remove(0);
                Booking.availableLowerBerths--;
            }
            else if (p.getBerthPrefer().equals("M")){
                System.out.println("Middle Berth given ");
                bookTickets.bookTickets(p, (Booking.middleBerthPositions.get(0)),"M");
                Booking.middleBerthPositions.remove(0);
                Booking.availableMiddleBerths--;
            }
            else if (p.getBerthPrefer().equals("U")) {
                System.out.println("Upper Berth given ");
                bookTickets.bookTickets(p, (Booking.upperBerthPositions.get(0)),"U");
                Booking.upperBerthPositions.remove(0);
                Booking.availableUpperBerths--;
            }
        }
        else if(Booking.availableLowerBerths>0){
            System.out.println("Preferred location not available so lower berth is given");
            bookTickets.bookTickets(p,(Booking.lowerBerthPositions.get(0)),"L");
            Booking.lowerBerthPositions.remove(0);
            Booking.availableLowerBerths--;
        }

        else if(Booking.availableMiddleBerths>0){
            System.out.println("Preferred location not available so middle berth is given");
            bookTickets.bookTickets(p,(Booking.middleBerthPositions.get(0)),"M");
            Booking.middleBerthPositions.remove(0);
            Booking.availableMiddleBerths--;
        }
        else if(Booking.availableUpperBerths>0){
            System.out.println("Preferred location not available so lower berth is given");
            bookTickets.bookTickets(p,(Booking.upperBerthPositions.get(0)),"U");
            Booking.upperBerthPositions.remove(0);
            Booking.availableUpperBerths--;
        }
        else if(Booking.availableRacTickets>0){
            System.out.println("RAC is available");
            bookTickets.addToRAC(p,(Booking.racPositions.get(0)),"RAC");
        }
        else if(Booking.availableWaitingList>0){
            System.out.println("RAC is available");
            bookTickets.addToWaitingList(p,(Booking.waitingListPositions.get(0)),"WL");
        }

    }

    public static void cancelTicket(int id){
        Booking booked = new Booking();
        if(!Booking.passengerList.containsKey(id)){
            System.out.println("Passenger details unknown");
        }
        else {
            booked.cancelTicket(id);
        }
    }
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        boolean loop = true;

        while(loop){
            System.out.println(" 1. Book Ticket \n 2. Cancel Ticket \n 3. Available Tickets \n 4. Booked Tickets \n 5. Exit \n ----------------------------");
            int choice = sc.nextInt();
            switch (choice){
                case 1:{
                    System.out.println("Enter the Passenger Details (name, Age, BerthPreference[L, U, M])");
                    String pName = sc.next();
                    int pAge = sc.nextInt();
                    String pBerthPrefer = sc.next();

                    Passenger p = new Passenger(pName, pAge, pBerthPrefer.toUpperCase());
                    bookTickets(p);
                }
                break;
                case 2:{
                    System.out.println("Enter Passenger Id to cancel a ticket");
                    int pId = sc.nextInt();
                    cancelTicket(pId);
                }
                break;
                case 3:{
                    Booking book = new Booking();
                    book.printAvailable();
                }
                break;
                case 4:{
                    Booking book = new Booking();
                    book.printPassengers();
                }
                break;
                case 5:{
                    loop = false;
                }
                break;

                default:
                    break;

            }
        }


    }

}