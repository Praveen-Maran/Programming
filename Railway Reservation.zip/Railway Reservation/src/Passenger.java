public class Passenger {

    static int id = 1;
    String name;
    int age;
    String berthPrefer; //(L, M, U)
    int passengerId;
    String alloted; // alloted type (L, M , U , RCA, WL)
    int number; // seat number

    public Passenger(String pName, int pAge, String pBerthPrefer){
        this.name = pName;
        this.age = pAge;
        this.berthPrefer = pBerthPrefer;
        this.passengerId = id++;
        alloted="";
        number = -1;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getBerthPrefer() {
        return berthPrefer;
    }

    public void setBerthPrefer(String berthPrefer) {
        this.berthPrefer = berthPrefer;
    }

    public int getPassengerId() {
        return passengerId;
    }

    public void setPassengerId(int passengerId) {
        this.passengerId = passengerId;
    }

    public String getAlloted() {
        return alloted;
    }

    public void setAlloted(String alloted) {
        this.alloted = alloted;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
