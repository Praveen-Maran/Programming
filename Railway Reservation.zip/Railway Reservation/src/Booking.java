
import java.util.*;

public class Booking {

    static int availableLowerBerths = 21;
    static int availableMiddleBerths = 21;
    static int availableUpperBerths = 21;
    static int availableRacTickets = 18;
    static int availableWaitingList = 10;

    // Total seating value in array
    static Integer[] totalBerth = new Integer[]{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21};
    static Integer[] totalRAC = new Integer[]{1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18};
    static Integer[] totalWL = new Integer[]{1,2,3,4,5,6,7,8,9,10};
    static Queue<Integer> waitingList = new LinkedList<>();
    static Queue<Integer> racList = new LinkedList<>();
    static List<Integer> bookedTickets = new ArrayList<>();

    static List<Integer> lowerBerthPositions = new ArrayList<>(Arrays.asList(totalBerth));
    static List<Integer> middleBerthPositions = new ArrayList<>(Arrays.asList(totalBerth));
    static List<Integer> upperBerthPositions = new ArrayList<>(Arrays.asList(totalBerth));
    static List<Integer> racPositions = new ArrayList<>(Arrays.asList(totalRAC));
    static List<Integer> waitingListPositions = new ArrayList<>(Arrays.asList(totalWL));

    static Map<Integer, Passenger> passengerList = new HashMap<>();

    //book ticket
    public void bookTickets(Passenger p, int berthInfo, String allotedBerth){
        // assign the seat number and berth type(L,U,M)
        p.setNumber(berthInfo);
        p.setAlloted(allotedBerth);
        // add passenger id and details in map
        passengerList.put(p.getPassengerId(), p);
        //add passenger id to the list of bookedTickets List
        bookedTickets.add(p.getPassengerId());
        System.out.println("--------------------Booked Successfully");

    }

    //adding to RAC
    public void addToRAC(Passenger p, int racInfo, String allotedBerth){
        //assign seat number and type(RAC)
        p.setNumber(racInfo);
        p.setAlloted(allotedBerth);
        //add passenger to map
        passengerList.put(p.getPassengerId(),p);
        //add passenger in rac list
        racList.add(p.getPassengerId());
        //decreased count of rac
        availableRacTickets--;
        //remove the position that was alloted to passenger
        racPositions.remove(0);

        System.out.println("--------------- added to RAC Successfully");
    }

    //adding to Waiting List
    public void addToWaitingList(Passenger p, int waitingListInfo, String allotedBerth){
        //assign seat number and type(WL)
        p.setNumber(waitingListInfo);
        p.setAlloted(allotedBerth);
        //add passenger to map;
        passengerList.put(p.getPassengerId(), p);
        //add passenger to waiting List
        waitingList.add(p.getPassengerId());

        availableWaitingList--;
        waitingListPositions.remove(0);
        System.out.println("--------------------- added to waiting List Successfully");
    }

    public void cancelTicket(int id){

        Passenger p = passengerList.get(id);
        passengerList.remove(id);

        bookedTickets.remove(Integer.valueOf(id));
        int positionBooked = p.getNumber();
        System.out.println("----------------------- cancelled successfully");

        if (p.getAlloted().equals("L")){
            availableLowerBerths++;
            lowerBerthPositions.add(positionBooked);
        }
        else if(p.getAlloted().equals("M")){
            availableMiddleBerths++;
            middleBerthPositions.add(positionBooked);
        }
        else if(p.getAlloted().equals("U")){
            availableUpperBerths++;
            upperBerthPositions.add(positionBooked);
        }

        if (racList.size()>0){
            Passenger passengerFromRAC = passengerList.get(racList.poll());
            int positionRAC = passengerFromRAC.getNumber();
            racPositions.add(positionRAC);
            racList.remove(id);
            availableRacTickets++;

            if(waitingList.size()>0){
                Passenger passengerFromWL = passengerList.get(waitingList.poll());
                int positionWL = passengerFromWL.getNumber();
                waitingListPositions.add(positionWL);
                waitingList.remove(id);
                availableWaitingList++;
                availableRacTickets--;
            }

            Main.bookTickets(passengerFromRAC);
        }
    }

    //print all available seats
    public void printAvailable()
    {
        System.out.println("Available Lower Berths "  + availableLowerBerths);
        System.out.println("Available Middle Berths "  + availableMiddleBerths);
        System.out.println("Available Upper Berths "  + availableUpperBerths);
        System.out.println("Available RACs " + availableRacTickets);
        System.out.println("Available Waiting List " + availableWaitingList);
        System.out.println("--------------------------");
    }
    //print booked passenger details
    public void printPassengers(){
        if(passengerList.size()==0){
            System.out.println("No details of passengers");
            return;
        }
        for (Passenger p : passengerList.values()){
            System.out.println("Passenger ID " +p.getPassengerId());
            System.out.println("Name " +p.getName());
            System.out.println("Age " +p.getAge());
            System.out.println("Status " +p.getNumber()+p.getAlloted());
            System.out.println("---------------------------");
        }
    }
}
