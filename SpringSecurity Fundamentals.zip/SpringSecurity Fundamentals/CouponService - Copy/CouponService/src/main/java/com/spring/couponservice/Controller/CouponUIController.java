package com.spring.couponservice.Controller;

import com.spring.couponservice.Model.Coupon;
import com.spring.couponservice.Repository.CouponRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CouponUIController {

    @Autowired
    private CouponRepo couponRepo;

    @GetMapping("/showCreateCoupon")
    public String create(){
        return "createCoupon";
    }
    @PostMapping("/saveCoupon")
    public String save(Coupon coupon){
        couponRepo.save(coupon);
        return "createResponse";
    }
    @GetMapping("/showGetCoupon")
    public String show(){
        return "getCoupon";
    }
    @PostMapping("/getCoupon")
    public ModelAndView getCoupon(String code){
        ModelAndView mv = new ModelAndView("couponDetails");
        mv.addObject(couponRepo.findByCode(code));
        return mv;
    }
}
