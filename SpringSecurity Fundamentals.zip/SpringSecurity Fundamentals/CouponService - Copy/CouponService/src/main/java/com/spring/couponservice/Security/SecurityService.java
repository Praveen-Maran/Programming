package com.spring.couponservice.Security;

public interface SecurityService {
    boolean login(String username, String password);
}
