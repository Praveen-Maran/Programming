package com.spring.couponservice.Security;

import com.spring.couponservice.Model.User;
import com.spring.couponservice.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserDetailsService {
    @Autowired
    private UserRepo userRepo;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepo.findByEmail(username);
        if(user == null) {
            System.out.println("Enter username is not found" + username);
            throw new UsernameNotFoundException("Enter username is not found" + username);
        }
        System.out.println(user.getRoles().toString());
        return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword() , user.getRoles());
    }
}
