package com.spring.couponservice.Controller;

import com.spring.couponservice.Model.Coupon;
import com.spring.couponservice.Repository.CouponRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/couponApi")
public class CouponController {

    @Autowired
    private CouponRepo couponRepo;
    @PostMapping("/create")
    public Coupon create(@RequestBody Coupon coupon){
        return couponRepo.save(coupon);
    }

    @GetMapping("/couponCode/{code}")
    public Coupon getCoupon(@PathVariable String code){
        return couponRepo.findByCode(code);

    }
}
