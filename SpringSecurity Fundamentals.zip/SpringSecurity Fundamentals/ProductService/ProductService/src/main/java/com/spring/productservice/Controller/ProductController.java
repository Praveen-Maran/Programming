package com.spring.productservice.Controller;

import com.spring.productservice.DTO.Coupon;
import com.spring.productservice.Model.Product;
import com.spring.productservice.Repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/productApi")
public class ProductController {

    @Autowired
    private ProductRepo productRepo;
    @Autowired
    private RestTemplate restTemplate;
    @Value("${couponService.url}")
    private String CouponServiceURL;

    @PostMapping("/products")
    public Product save(@RequestBody Product product){
        Coupon coupon = restTemplate.getForObject(CouponServiceURL+product.getCouponCode(), Coupon.class);
        product.setPrice(product.getPrice().subtract(coupon.getDiscount()));
        return productRepo.save(product);
    }
}
